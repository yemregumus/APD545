package org.example.invmanagement.exceptions;

public class PartDetailsException extends Exception {
    public PartDetailsException(String message) {
        super(message);
    }
}