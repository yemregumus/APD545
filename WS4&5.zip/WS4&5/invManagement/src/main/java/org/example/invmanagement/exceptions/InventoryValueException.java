package org.example.invmanagement.exceptions;

// InventoryValueException.java
public class InventoryValueException extends Exception {
    public InventoryValueException(String message) {
        super(message);
    }
}