package org.example.invmanagement.exceptions;

public class ConfirmActionException extends Exception {
    public ConfirmActionException(String message) {
        super(message);
    }
}