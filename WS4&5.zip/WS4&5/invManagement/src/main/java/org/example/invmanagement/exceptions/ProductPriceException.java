package org.example.invmanagement.exceptions;

// ProductPriceException.java
public class ProductPriceException extends Exception {
    public ProductPriceException(String message) {
        super(message);
    }
}