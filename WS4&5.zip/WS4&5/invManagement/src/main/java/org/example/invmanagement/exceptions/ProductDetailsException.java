package org.example.invmanagement.exceptions;

// ProductDetailsException.java
public class ProductDetailsException extends Exception {
    public ProductDetailsException(String message) {
        super(message);
    }
}