package org.example.invmanagement.exceptions;

// ProductPartException.java
public class ProductPartException extends Exception {
    public ProductPartException(String message) {
        super(message);
    }
}