package org.example.invmanagement.exceptions;

public class ProductPartsException extends Exception {
    public ProductPartsException(String message) {
        super(message);
    }
}
