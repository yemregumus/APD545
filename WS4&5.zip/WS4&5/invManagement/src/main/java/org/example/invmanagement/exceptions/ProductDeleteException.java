package org.example.invmanagement.exceptions;

// ProductDeleteException.java
public class ProductDeleteException extends Exception {
    public ProductDeleteException(String message) {
        super(message);
    }
}